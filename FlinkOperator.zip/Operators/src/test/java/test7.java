import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.typeutils.RowTypeInfo;
import org.apache.flink.runtime.state.filesystem.FsStateBackend;
import org.apache.flink.runtime.state.memory.MemoryStateBackend;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.DataStream;

import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.apache.flink.table.api.Table;
import org.apache.flink.table.api.Types;
import org.apache.flink.table.api.java.StreamTableEnvironment;
import org.apache.flink.types.Row;
import org.junit.Test;

import java.util.Date;


/**
 * @author ：zz
 * @date ：Created in 2019/10/9 17:09
 */

public class test7 {
//   private static ArrayList<Row> arrayList = new ArrayList<Row>(5);

    @Test
    public void  test() throws Exception {


        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        DataStream<Row> rowDataStreamSource = env.addSource(new SourceFunction<Row>() {
            int count = 0;
            int num = 0;
            long time3 = System.currentTimeMillis();
            @Override
            public void run(SourceContext<Row> ctx) throws Exception {
                while(true) {
                    long time1 = System.currentTimeMillis();
                    count++;


                    ctx.collect(Row.of("jack", "www.taobao.com",    time3, num));
                    Thread.sleep(1000);
                    ctx.collect(Row.of("tom", "www.baidu.com",    time3, num));
                    Thread.sleep(1000);
                    ctx.collect(Row.of("bob", "www.jingdong.com",    time3, num));
                    Thread.sleep(1000);


                }
            }

            @Override
            public void cancel() {

            }
        });
//
        env.enableCheckpointing(1000);
        env.setStateBackend(new MemoryStateBackend());
        env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime);
        StreamTableEnvironment tEnv = StreamTableEnvironment.getTableEnvironment(env);
        DataStream<Row> ds = rowDataStreamSource.map((MapFunction) (row -> row))
                .returns(Types.ROW(new String[]{"NAME", "HOST", "EVENT_TIME", "NUM"}, new TypeInformation[]{Types.STRING(), Types.STRING(), Types.LONG(), Types.INT()}));
        long l = System.currentTimeMillis();



        //Caused by: java.lang.RuntimeException: Rowtime timestamp is null. Please make sure that a proper TimestampAssigner is defined and the stream environment uses the EventTime time characteristic.

        Table table = tEnv.fromDataStream(ds,"NAME,HOST,times.rowtime,NUM");
        tEnv.registerTable("TEST",table);
        Table table11 = tEnv.sqlQuery("select *,CURRENT_TIME as c_T,CURRENT_DATE as c_d  from TEST");
//        table11.printSchema();
        tEnv.registerTable("TEST2",table11);
        RowTypeInfo inputRowTypeInfo = (RowTypeInfo) table.getSchema().toRowType();
        System.out.println("in = "+inputRowTypeInfo);
        Table table1 = tEnv.sqlQuery("  " +
                "SELECT " +
                "NAME,cast(timestampadd(hour,8,TUMBLE_START(times,INTERVAL '4' second)) as varchar),COUNT(HOST) FROM  TEST2 f GROUP BY TUMBLE(f.times,INTERVAL '4' second),f.NAME"
        );
        table1.printSchema();
        DataStream<Tuple2<Boolean, Row>> d23 = tEnv.toRetractStream(table1, Row.class);

        d23.print();
        env.execute();
    }
}




